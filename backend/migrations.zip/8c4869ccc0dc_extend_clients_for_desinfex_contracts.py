"""extend clients for desinfex contracts

Revision ID: 8c4869ccc0dc
Revises: 39a30821a422
Create Date: 2026-02-08 14:48:07.463569

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '8c4869ccc0dc'
down_revision: Union[str, Sequence[str], None] = '39a30821a422'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade():
    op.add_column("clients", sa.Column("vat_number", sa.String(length=50), nullable=True))
    op.add_column("clients", sa.Column("address", sa.String(length=255), nullable=True))
    op.add_column("clients", sa.Column("postal_code", sa.String(length=20), nullable=True))
    op.add_column("clients", sa.Column("city", sa.String(length=120), nullable=True))

    op.add_column("clients", sa.Column("pest_type", sa.String(length=120), nullable=True))
    op.add_column("clients", sa.Column("notes", sa.String(length=500), nullable=True))

    op.add_column("clients", sa.Column("has_contract", sa.Boolean(), server_default="false"))
    op.add_column("clients", sa.Column("contract_start_date", sa.Date(), nullable=True))
    op.add_column("clients", sa.Column("visits_per_year", sa.Integer(), nullable=True))

    op.add_column("clients", sa.Column("is_active", sa.Boolean(), server_default="true"))



def downgrade() -> None:
    """Downgrade schema."""
    pass
