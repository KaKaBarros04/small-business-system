"""create company_permissions table

Revision ID: c06b0cf3d8a2
Revises: bd4ba979135c
Create Date: 2026-02-23 17:49:46.853109

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = 'c06b0cf3d8a2'
down_revision: Union[str, Sequence[str], None] = 'bd4ba979135c'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "company_permissions",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), nullable=False, unique=True),
        sa.Column(
            "staff_permissions",
            postgresql.JSONB(astext_type=sa.Text()),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.ForeignKeyConstraint(
            ["company_id"],
            ["companies.id"],
            ondelete="CASCADE",
        ),
    )

    op.create_index(
        "ix_company_permissions_company_id",
        "company_permissions",
        ["company_id"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index("ix_company_permissions_company_id", table_name="company_permissions")
    op.drop_table("company_permissions")