"""add contract_id to appointments

Revision ID: d00637523a4e
Revises: 8c4869ccc0dc
Create Date: 2026-02-08 18:03:27.753285

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = 'd00637523a4e'
down_revision: Union[str, Sequence[str], None] = '8c4869ccc0dc'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    # contracts
    op.create_table(
        'contracts',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('company_id', sa.Integer(), nullable=False),
        sa.Column('client_id', sa.Integer(), nullable=False),
        sa.Column('start_date', sa.Date(), nullable=False),
        sa.Column('end_date', sa.Date(), nullable=False),
        sa.Column('visits_per_year', sa.Integer(), nullable=False),
        sa.Column('cutoff_days', sa.Integer(), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False),
        sa.Column('created_at', sa.Date(), nullable=False),
        sa.ForeignKeyConstraint(['client_id'], ['clients.id']),
        sa.ForeignKeyConstraint(['company_id'], ['companies.id']),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_contracts_client_id'), 'contracts', ['client_id'], unique=False)
    op.create_index(op.f('ix_contracts_company_id'), 'contracts', ['company_id'], unique=False)
    op.create_index(op.f('ix_contracts_id'), 'contracts', ['id'], unique=False)

    # cleanup legado (idempotente)
    op.execute("DROP INDEX IF EXISTS ix_google_calendar_sync_channel_id")
    op.execute("DROP INDEX IF EXISTS ix_google_calendar_sync_company_id")
    op.execute("DROP INDEX IF EXISTS ix_google_calendar_sync_id")
    op.execute("DROP INDEX IF EXISTS ix_google_calendar_sync_resource_id")
    op.execute("DROP TABLE IF EXISTS google_calendar_sync CASCADE")

    op.execute("DROP INDEX IF EXISTS ix_audit_logs_company_id")
    op.execute("DROP INDEX IF EXISTS ix_audit_logs_id")
    op.execute("DROP INDEX IF EXISTS ix_audit_logs_user_id")
    op.execute("DROP TABLE IF EXISTS audit_logs CASCADE")

    # appointments (idempotente)
    op.execute("ALTER TABLE appointments ADD COLUMN IF NOT EXISTS contract_id INTEGER")
    op.execute("ALTER TABLE appointments ADD COLUMN IF NOT EXISTS is_contract_visit BOOLEAN")

    # garante default + preenche nulls + NOT NULL (seguro)
    op.execute("ALTER TABLE appointments ALTER COLUMN is_contract_visit SET DEFAULT FALSE")
    op.execute("UPDATE appointments SET is_contract_visit = FALSE WHERE is_contract_visit IS NULL")
    op.execute("""
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_name='appointments' AND column_name='is_contract_visit'
  ) THEN
    ALTER TABLE appointments ALTER COLUMN is_contract_visit SET NOT NULL;
  END IF;
END$$;
""")

    op.execute("DROP INDEX IF EXISTS idx_appointments_google_event_id")
    op.create_index(op.f('ix_appointments_contract_id'), 'appointments', ['contract_id'], unique=False)
    op.create_foreign_key(None, 'appointments', 'contracts', ['contract_id'], ['id'])

    # coluna pode não existir
    op.execute("ALTER TABLE appointments DROP COLUMN IF EXISTS google_event_html_link")

    # clients extras (idempotente)
    op.execute("ALTER TABLE clients ADD COLUMN IF NOT EXISTS vat_number VARCHAR(50)")
    op.execute("ALTER TABLE clients ADD COLUMN IF NOT EXISTS address VARCHAR(255)")
    op.execute("ALTER TABLE clients ADD COLUMN IF NOT EXISTS postal_code VARCHAR(20)")
    op.execute("ALTER TABLE clients ADD COLUMN IF NOT EXISTS city VARCHAR(120)")
    op.execute("ALTER TABLE clients ADD COLUMN IF NOT EXISTS pest_type VARCHAR(120)")
    op.execute("ALTER TABLE clients ADD COLUMN IF NOT EXISTS notes VARCHAR(500)")
    op.execute("ALTER TABLE clients ADD COLUMN IF NOT EXISTS has_contract BOOLEAN")
    op.execute("ALTER TABLE clients ADD COLUMN IF NOT EXISTS contract_start_date DATE")
    op.execute("ALTER TABLE clients ADD COLUMN IF NOT EXISTS visits_per_year INTEGER")
    op.execute("ALTER TABLE clients ADD COLUMN IF NOT EXISTS is_active BOOLEAN")

    # altera phone só se existir
    op.execute("""
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_name='clients' AND column_name='phone'
  ) THEN
    ALTER TABLE clients ALTER COLUMN phone TYPE VARCHAR(50);
  END IF;
END$$;
""")

    # users.company_id só se existir
    op.execute("""
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_name='users' AND column_name='company_id'
  ) THEN
    ALTER TABLE users ALTER COLUMN company_id DROP NOT NULL;
  END IF;
END$$;
""")

    # check constraint só se não existir
    op.execute("""
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'users_company_required_except_group'
  ) THEN
    ALTER TABLE users
      ADD CONSTRAINT users_company_required_except_group
      CHECK (company_id IS NOT NULL OR role = 'GROUP_ADMIN');
  END IF;
END$$;
""")


def downgrade() -> None:
    """Downgrade schema."""
    # Mantive teu downgrade original. (Downgrade raramente usado; pode falhar se schema estiver diferente)
    op.alter_column('users', 'company_id',
                    existing_type=sa.INTEGER(),
                    nullable=True)

    op.alter_column('clients', 'phone',
                    existing_type=sa.String(length=50),
                    type_=sa.VARCHAR(length=20),
                    existing_nullable=True)

    op.drop_column('clients', 'is_active')
    op.drop_column('clients', 'visits_per_year')
    op.drop_column('clients', 'contract_start_date')
    op.drop_column('clients', 'has_contract')
    op.drop_column('clients', 'notes')
    op.drop_column('clients', 'pest_type')
    op.drop_column('clients', 'city')
    op.drop_column('clients', 'postal_code')
    op.drop_column('clients', 'address')
    op.drop_column('clients', 'vat_number')

    op.add_column('appointments', sa.Column('google_event_html_link', sa.TEXT(), autoincrement=False, nullable=True))
    op.drop_constraint(None, 'appointments', type_='foreignkey')

    op.execute("DROP INDEX IF EXISTS ix_appointments_contract_id")
    op.create_index(op.f('idx_appointments_google_event_id'), 'appointments', ['google_event_id'], unique=False)

    op.drop_column('appointments', 'is_contract_visit')
    op.drop_column('appointments', 'contract_id')

    op.create_table(
        'audit_logs',
        sa.Column('id', sa.INTEGER(), autoincrement=True, nullable=False),
        sa.Column('company_id', sa.INTEGER(), autoincrement=False, nullable=False),
        sa.Column('user_id', sa.INTEGER(), autoincrement=False, nullable=True),
        sa.Column('action', sa.VARCHAR(length=20), autoincrement=False, nullable=False),
        sa.Column('entity', sa.VARCHAR(length=100), autoincrement=False, nullable=False),
        sa.Column('entity_id', sa.INTEGER(), autoincrement=False, nullable=True),
        sa.Column('old_values', postgresql.JSON(astext_type=sa.Text()), autoincrement=False, nullable=True),
        sa.Column('new_values', postgresql.JSON(astext_type=sa.Text()), autoincrement=False, nullable=True),
        sa.Column('ip', sa.VARCHAR(length=64), autoincrement=False, nullable=True),
        sa.Column('user_agent', sa.VARCHAR(length=255), autoincrement=False, nullable=True),
        sa.Column('created_at', postgresql.TIMESTAMP(), server_default=sa.text('now()'), autoincrement=False, nullable=False),
        sa.ForeignKeyConstraint(['company_id'], ['companies.id'], name=op.f('audit_logs_company_id_fkey')),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], name=op.f('audit_logs_user_id_fkey')),
        sa.PrimaryKeyConstraint('id', name=op.f('audit_logs_pkey')),
    )
    op.create_index(op.f('ix_audit_logs_user_id'), 'audit_logs', ['user_id'], unique=False)
    op.create_index(op.f('ix_audit_logs_id'), 'audit_logs', ['id'], unique=False)
    op.create_index(op.f('ix_audit_logs_company_id'), 'audit_logs', ['company_id'], unique=False)

    op.create_table(
        'google_calendar_sync',
        sa.Column('company_id', sa.INTEGER(), autoincrement=False, nullable=False),
        sa.Column('calendar_id', sa.VARCHAR(length=512), autoincrement=False, nullable=False),
        sa.Column('channel_id', sa.VARCHAR(length=255), autoincrement=False, nullable=True),
        sa.Column('resource_id', sa.VARCHAR(length=255), autoincrement=False, nullable=True),
        sa.Column('sync_token', sa.VARCHAR(length=2048), autoincrement=False, nullable=True),
        sa.Column('updated_at', postgresql.TIMESTAMP(), server_default=sa.text('now()'), autoincrement=False, nullable=False),
        sa.Column('id', sa.INTEGER(), autoincrement=False, nullable=False),
        sa.Column('created_at', postgresql.TIMESTAMP(), autoincrement=False, nullable=False),
        sa.ForeignKeyConstraint(['company_id'], ['companies.id'], name=op.f('google_calendar_sync_company_id_fkey')),
        sa.PrimaryKeyConstraint('company_id', name=op.f('google_calendar_sync_pkey')),
    )
    op.create_index(op.f('ix_google_calendar_sync_resource_id'), 'google_calendar_sync', ['resource_id'], unique=False)
    op.create_index(op.f('ix_google_calendar_sync_id'), 'google_calendar_sync', ['id'], unique=False)
    op.create_index(op.f('ix_google_calendar_sync_company_id'), 'google_calendar_sync', ['company_id'], unique=False)
    op.create_index(op.f('ix_google_calendar_sync_channel_id'), 'google_calendar_sync', ['channel_id'], unique=False)

    op.execute("DROP INDEX IF EXISTS ix_contracts_id")
    op.execute("DROP INDEX IF EXISTS ix_contracts_company_id")
    op.execute("DROP INDEX IF EXISTS ix_contracts_client_id")
    op.execute("DROP TABLE IF EXISTS contracts CASCADE")