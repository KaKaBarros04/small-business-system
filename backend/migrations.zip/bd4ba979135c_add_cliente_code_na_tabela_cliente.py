"""add cliente_code na tabela cliente

Revision ID: bd4ba979135c
Revises: 088b5607c597
Create Date: 2026-02-14 14:30:55.334374

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = 'bd4ba979135c'
down_revision: Union[str, Sequence[str], None] = '088b5607c597'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    # index legacy
    op.execute("DROP INDEX IF EXISTS uq_clients_company_client_code")

    # companies columns legacy (idempotente)
    op.execute("ALTER TABLE companies DROP COLUMN IF EXISTS legal_name")
    op.execute("ALTER TABLE companies DROP COLUMN IF EXISTS country")
    op.execute("ALTER TABLE companies DROP COLUMN IF EXISTS city")
    op.execute("ALTER TABLE companies DROP COLUMN IF EXISTS postal_code")


def downgrade() -> None:
    """Downgrade schema."""
    # downgrade (melhor esforço)
    op.add_column('companies', sa.Column('postal_code', sa.VARCHAR(length=20), autoincrement=False, nullable=True))
    op.add_column('companies', sa.Column('city', sa.VARCHAR(length=120), autoincrement=False, nullable=True))
    op.add_column('companies', sa.Column('country', sa.VARCHAR(length=80), autoincrement=False, nullable=True))
    op.add_column('companies', sa.Column('legal_name', sa.VARCHAR(length=200), autoincrement=False, nullable=True))
    op.execute("DROP INDEX IF EXISTS uq_clients_company_client_code")