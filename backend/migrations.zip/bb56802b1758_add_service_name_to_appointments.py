"""add service_name to appointments

Revision ID: bb56802b1758
Revises: c06b0cf3d8a2
Create Date: 2026-02-24 00:14:18.460395

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'bb56802b1758'
down_revision: Union[str, Sequence[str], None] = 'c06b0cf3d8a2'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("appointments", sa.Column("service_name", sa.String(length=255), nullable=True))
    # opcional (se quiser preço no agendamento):
    op.add_column("appointments", sa.Column("service_price", sa.Numeric(10, 2), nullable=True))


def downgrade() -> None:
    op.drop_column("appointments", "service_price")
    op.drop_column("appointments", "service_name")