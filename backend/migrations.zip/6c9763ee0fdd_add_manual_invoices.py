"""add manual invoices

Revision ID: <GERADO_PELO_ALEMBIC>
Revises: <REV_ANTERIOR>
Create Date: 2026-01-xx

"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = "6c9763ee0fdd"
down_revision: Union[str, Sequence[str], None] = "a80bbff2e379"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade():
    op.create_table(
        "manual_invoices",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id"), nullable=False),

        sa.Column("supplier_name", sa.String(length=200), nullable=False),
        sa.Column("invoice_number", sa.String(length=80), nullable=False),
        sa.Column("issue_date", sa.DateTime(), nullable=False),
        sa.Column("due_date", sa.DateTime(), nullable=True),

        sa.Column("status", sa.String(length=20), nullable=False, server_default="ISSUED"),
        sa.Column("paid_at", sa.DateTime(), nullable=True),

        sa.Column("subtotal", sa.Float(), nullable=False, server_default="0"),
        sa.Column("tax", sa.Float(), nullable=False, server_default="0"),
        sa.Column("total", sa.Float(), nullable=False, server_default="0"),

        sa.Column("notes", sa.String(length=500), nullable=True),
        sa.Column("pdf_path", sa.String(length=255), nullable=True),

        sa.Column("created_by_user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("updated_by_user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.text("NOW()")),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
    )

    op.create_index("ix_manual_invoices_id", "manual_invoices", ["id"])
    op.create_index("ix_manual_invoices_company_id", "manual_invoices", ["company_id"])
    op.create_index("ix_manual_invoices_status", "manual_invoices", ["status"])
    op.create_index("ix_manual_invoices_issue_date", "manual_invoices", ["issue_date"])

    # (company_id, invoice_number) único — evita duplicado da mesma fatura na mesma empresa
    op.create_index(
        "uq_manual_invoices_company_number",
        "manual_invoices",
        ["company_id", "invoice_number"],
        unique=True,
    )

    op.create_table(
        "manual_invoice_items",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("manual_invoice_id", sa.Integer(), sa.ForeignKey("manual_invoices.id", ondelete="CASCADE"), nullable=False),

        sa.Column("description", sa.String(length=255), nullable=False),
        sa.Column("qty", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("unit_price", sa.Float(), nullable=False, server_default="0"),
        sa.Column("line_total", sa.Float(), nullable=False, server_default="0"),
    )

    op.create_index("ix_manual_invoice_items_id", "manual_invoice_items", ["id"])
    op.create_index("ix_manual_invoice_items_company_id", "manual_invoice_items", ["company_id"])
    op.create_index("ix_manual_invoice_items_manual_invoice_id", "manual_invoice_items", ["manual_invoice_id"])


def downgrade():
    op.drop_table("manual_invoice_items")
    op.drop_table("manual_invoices")
