"""add google fields to appointments

Revision ID: 39a30821a422
Revises: af6a6fda5cd1
Create Date: 2026-01-30 16:14:48.213631

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '39a30821a422'
down_revision: Union[str, Sequence[str], None] = 'af6a6fda5cd1'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade():
    op.add_column("appointments", sa.Column("google_event_id", sa.String(length=255), nullable=True))
    op.add_column("appointments", sa.Column("google_sync_error", sa.String(length=500), nullable=True))
    op.create_index("ix_appointments_google_event_id", "appointments", ["google_event_id"])

def downgrade():
    op.drop_index("ix_appointments_google_event_id", table_name="appointments")
    op.drop_column("appointments", "google_sync_error")
    op.drop_column("appointments", "google_event_id")
