"""add user role

Revision ID: af6a6fda5cd1
Revises: b6c5a1a3b481
Create Date: 2026-01-29 23:21:05.256218

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'af6a6fda5cd1'
down_revision: Union[str, Sequence[str], None] = 'b6c5a1a3b481'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade():
    op.add_column("users", sa.Column("role", sa.String(length=20), nullable=False, server_default="USER"))
    op.create_index("ix_users_role", "users", ["role"])

def downgrade():
    op.drop_index("ix_users_role", table_name="users")
    op.drop_column("users", "role")